package com.openGDSMobile.airQuality;

import java.util.Map;

public interface AirQualityService {

	void requestAirQualityMapCreate(Map<String,Object> data);
}


