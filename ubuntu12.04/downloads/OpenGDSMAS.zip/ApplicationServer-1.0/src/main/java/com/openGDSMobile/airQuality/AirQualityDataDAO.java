package com.openGDSMobile.airQuality;

public interface AirQualityDataDAO {

	void createMap(String airEnvironmentJSON_filePath);
}
