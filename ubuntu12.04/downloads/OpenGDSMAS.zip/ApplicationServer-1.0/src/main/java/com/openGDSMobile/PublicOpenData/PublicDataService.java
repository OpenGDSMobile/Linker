package com.openGDSMobile.PublicOpenData;

import java.util.Map; 

public interface PublicDataService {

	Object requestPublicData(Map<String,Object> data);
}
